DC-10 3D Cockpit Starter Pack

This pack is designed to be used with the Aerobridge DC-10 freeware aircraft for X-Plane.

IMPORTANT:

- Download and install the Aerobridge DC-10 aircraft first.
- This pack only contains a basic 3D cockpit model and panel files — it is NOT a full aircraft.
- You must take the "cockpit.obj" file inside the "cockpit 3-D" folder and move it into the aircraft's "objects" folder.
- If the "objects" folder does not exist, please create it inside the aircraft folder.
- Leave the rest of the "cockpit 3-D" folder files (panel, instruments, textures) where they are.
- This is a starter pack and may not work perfectly. Modifications and improvements are expected.
- Feel free to remix, improve, and include this pack in your own DC-10 projects.

Thank you for helping bring the DC-10 back to life in X-Plane!
Happy flying and happy modding!